<?php
//Load Custom Widget
require_once (XZOPRO_ACC_PATH . '/inc/widgets/recent-post-widget.php');
require_once (XZOPRO_ACC_PATH . '/inc/widgets/about-widget.php');
require_once (XZOPRO_ACC_PATH . '/inc/widgets/address-widget.php');