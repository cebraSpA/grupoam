<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

//Xzopro All Custom Posts
require_once('slider-cp.php'); // cp = custom post
require_once('projects-cp.php');
require_once('testimonial-cp.php');