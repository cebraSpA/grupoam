<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Xzopro All Shortcodes

require_once('slider-shortcode.php');
require_once('projects-shortcode.php');
require_once('projects-gallery-and-details-shortcode.php');
require_once('section-title-shortcode.php');
require_once('about-box-shortcode.php');
require_once('service-box-shortcode.php');
require_once('choose-us-shortcode.php');
require_once('testimonial-shortcode.php');
require_once('pricing-table-shortcode.php');
require_once('counter-box-shortcode.php');
require_once('brand-slider-shortcode.php');
require_once('cta-shortcode.php');
require_once('recent-post-shortcode.php');
require_once('google-map-shortcode.php');
require_once('button-shortcode.php');
require_once('video-popup-shortcode.php');
require_once('team-member-shortcode.php');
require_once('progress-bar-shortcode.php');
require_once('text-with-button-shortcode.php');
require_once('text-with-border-image-shortcode.php');
require_once('text-with-title-shortcode.php');
require_once('text-with-image-and-list-shortcode.php');
require_once('text-with-background-color-shortcode.php');
require_once('unordered-list-item-shortcode.php');
require_once('contact-info-shortcode.php');